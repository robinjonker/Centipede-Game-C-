// Headers
#include "../header_files/Game.h"

int main()
{
    //Construction of Game Object
    Game CurrentGame;

    //Call to main menu function
    CurrentGame.Menu();

    return EXIT_SUCCESS;

}

