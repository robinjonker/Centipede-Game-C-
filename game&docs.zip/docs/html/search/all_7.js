var searchData=
[
  ['resetddtfield_87',['ResetDDTField',['../class_d_d_t_field.html#aeef61cfbf3b8758e3e526fb46f2f7d43',1,'DDTField']]],
  ['resetplayerposition_88',['resetPlayerPosition',['../class_player.html#ab41fe5fcfcd31658032383927b874664',1,'Player']]],
  ['resetshootposition_89',['resetShootPosition',['../class_shoot.html#a3e6a8832598afe392b04ac0221d7549d',1,'Shoot']]]
];
